import React  from 'react';
import Footer from './Footer';


function Books (props){
    return(
        <div>
            {props.books.map(f => <p key={f.id}>{f.BookName} by {f.Author}</p>)}
        </div>
        
    );
}
function Content (){

    const [books] = React.useState([
        {BookName: 'The Alchemist', Author:'poulo ceolo', id: 1},
        {BookName: 'Dhoni the untold story', Author:'MS', id: 2},
        {BookName: 'Antaryami',Author:'Bawa Batuknath', id: 3},
        {BookName: 'Ikigai',Author:'Keira Miki', id: 4},
        {BookName: 'Monk who sold his Ferari',Author:'John', id: 5},
        {BookName: 'Diary of a young girl',Author:'Anne Frank', id: 6},
        {BookName: 'The invisible man',Author:'Peter', id: 7},
        {BookName: 'Three man in a boat',Author:'Ema', id: 8},


    ]);
    return(
        <div>
            <h1>Nobel List</h1>
            <Books books={books} />
            <Footer books={books} />
        </div>
    );
}

export default Content;