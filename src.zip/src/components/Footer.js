import React  from 'react';

function Footer(props){
    // if(props.vid){
    // return  ( 
    // <div className="footer">
    //     <h5>  The number of content: {props.vid.length} </h5>
    // </div>
    // );
    // }
    // else{
        return (<div className="footer">
        <h5>  The number of contents: {props.numOfVid}</h5>
    </div>)
    }


export default Footer 

//{props.arr.length}