import React, { Component } from 'react';
import Card from './CardUI';
import img1 from '../assets/msd.jpg';
import img2 from '../assets/Alchemist.jpg';
import img3 from '../assets/invisible man.jpg';
import img4 from '../assets/Ironman.jpg';
import img5 from '../assets/Batman.jpg';
import img6 from '../assets/Twilight.jpg';
import img7 from '../assets/Spiderman.jpg';
import img8 from '../assets/Titanic.jpg';
import img9 from '../assets/Founder.jpg';
import Footer from './Footer';

// function Books (props){
//     return(
//         <div>
//             {props.vid.map(f => <p key={f.id}>{f.title} by {f.description}</p>)}
//         </div>

//     );
// }
// function Content (){

//     const [books] = React.useState([
//         {BookName: 'The Alchemist', Author:'poulo ceolo', id: 1},
//         {BookName: 'Dhoni the untold story', Author:'MS', id: 2},
//         {BookName: 'Antaryami',Author:'Bawa Batuknath', id: 3},
//         {BookName: 'Ikigai',Author:'Keira Miki', id: 4},
//         {BookName: 'Monk who sold his Ferari',Author:'John', id: 5},
//         {BookName: 'Diary of a young girl',Author:'Anne Frank', id: 6},
//         {BookName: 'The invisible man',Author:'Peter', id: 7},
//         {BookName: 'Three man in a boat',Author:'Ema', id: 8},
//     ]);
// return(
//     <div>
//         <h1>Nobel List</h1>
//         {/* <Books books={books} /> */}
//         <Books vid={vid} />
//         {/* <Footer books={books} /> */}
//         <Footer vid={vid} />
//     </div>
// );
// }

const vid = [{
    img: img6,
    title: 'Twilight ',
    description: 'IMDb : 8.9',
    price: '₹ 250',
    id: 1
}, {
    img: img2,
    title: 'The Alchemist',
    description: 'IMDb : 9',
    price: '₹ 150',
    id: 2
}, {
    img: img3,
    title: 'The Invisible man',
    description: 'IMDb : 8.3',
    price: '₹ 200',
    id: 3
}, {
    img: img4,
    title: 'Ironman',
    description: 'IMDb : 8.5',
    price: '₹ 270',
    id: 4
}, {
    img: img5,
    title: 'Batman',
    description: 'IMDb : 9.1',
    price: '₹ 160',
    id: 5
}, {
    img: img1,
    title: 'Ms Dhoni',
    description: 'IMDb : 8.8',
    price: '₹ 270',
    id: 6
}, {
    img: img7,
    title: 'Spiderman 3',
    description: 'IMDb : 8.1',
    price: '₹ 180',
    id: 7
}, {
    img: img8,
    title: 'Titanic',
    description: 'IMDb : 8.7',
    price: '₹ 220',
    id: 8
}, {
    img: img9,
    title: 'The Founder',
    description: 'IMDb : 8.2',
    price: '₹ 210',
    id: 9
}
]

class Cards extends Component {

    render() {
        return (
            <div className="container-fliud d-flex justify-content-center ">
                <div className='row'>
                    {
                        this.props.vid.map((val, i) => {
                            return (
                                <div className="col-md-3 disp-flex" key={i}>
                                    <Card data={val} setSelectedItem={this.props.setSelectedItem} selectedItems={this.props.selectedItems} />
                                    {/* <Footer arrs={arr} /> */}
                                </div>


                            )
                        })
                    }
                    {/*  <div className="col-md-4">
                        <Card imgsrc={img1} title="MS Dhoni" des="A Ganguly" price="₹ 250" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img2} title="The Alchemist" des="Paulo Coelho" price="₹ 350" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img3} title="The Invisible man" des="Jhon" price="₹ 220" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img4} title="Iron Man" des="Peter" price="₹ 220" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img5} title="Batman" des="Philip" price="₹ 220" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img6} title="Twilight" des="Jhon" price="₹ 220" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img7} title="Spiderman" des="Jhon" price="₹ 220" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img8} title="Titanic" des="Jhon" price="₹ 220" />
                    </div>
                    <div className="col-md-4">
                        <Card imgsrc={img9} title="The founder" des="Jhon" price="₹ 220" />
                    </div> */}
                </div>
            </div>

        );
    }
}

export default Cards;