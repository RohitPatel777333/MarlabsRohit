import React from 'react';
import './card-style.css';
import Cart from '../Cart';
//import Footer from './Footer';
import { useState } from 'react';
import { Link } from 'react-router-dom';
//import img1 from '../assets/msd.jpg';
//import img2 from '../assets/Alchemist.jpg';

const bird1 = new Audio(
    "https://upload.wikimedia.org/wikipedia/commons/9/9b/Hydroprogne_caspia_-_Caspian_Tern_XC432679.mp3"
);

const Card = props => {
    const [audios, setAudios] = useState("play");
    const { data: { img, title, des, price }, setSelectedItem, selectedItems } = props;

    const toggle1 = () => {
        console.log(bird1.paused)
        //if (bird1.paused) {
        if (bird1.paused) {
            console.log("should play");
            bird1.play();
            setAudios("pause");
        } else {
            console.log("should pause");
            bird1.pause();
            setAudios("play");
        }
    };

    const addToCart = (data) => {
        const items = [...selectedItems];
        items.push(data);
        setSelectedItem(items);
    }

    return (
        <><div className='card text-Centre'>
            <div className='overflow'>
                <img src={img} alt='Image 1' className='card-img-top' />
            </div>
            <div className='card-body text-dark'>
                <h4 className='card-title top-right '>{title}</h4>
                <p className='card-text text-secondary text-dark '>
                    {des}
                </p>&emsp;
                <button className='btn btn-outline-success' onClick={() => toggle1()}>{audios}</button>
                &emsp;
                <button className='btn btn-outline-success' onClick={() => addToCart(props.data)}
                //         onClick={() => {
                //         console.log("this is add to cart");
                //         var oldData = [];
                //         if (
                //             JSON.parse(sessionStorage.getItem("selectedCartItems"))
                //         ) {
                //         oldData = JSON.parse(
                //         sessionStorage.getItem("selectedCartItems")
                // );
                // }
                //     oldData.push(vid);
                //     sessionStorage.setItem(
                //     "selectedCartItems",
                //     JSON.stringify(oldData)
                // );
                // alert("item added to cart");
                // }} 
                >Add to Cart</button>
                &emsp;
                {/* <a>  {props.price}</a> */}
                <a href='#' className='btn btn-outline-success float-right'>  {price}</a>

            </div>


            {/* </div><div className='card text-Centre'>
                <div className='overflow'>
                    <img src={img2} alt='Image 2' className='card-img-right'/>
                </div>
                <div className='card-body text-dark'>
                    <h4 className='card-title'>The Alchemist</h4>
                    <p className='card-text text-secondary'>
                        Paulo coelho
                    </p>
                    <a href='#' className='btn btn-outline-success'> {props.price} </a>
                </div> */}
        </div></>

    );
}

export default Card;