import Cards from "./components/Cards";
import Footer from "./components/Footer";



function Home(props) {
    return (
        <div>
            <h1>Welcome to the Netflix</h1>
            <Cards vid={props.vid} setSelectedItem={props.setSelectedItem} selectedItems={props.selectedItems}/>
            <Footer numOfVid={props.vid.length} />
        </div>

    )
}

export default Home
