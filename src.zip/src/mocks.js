import img1 from './assets/msd.jpg';
import img2 from './assets/Alchemist.jpg';
import img3 from './assets/invisible man.jpg';
import img4 from './assets/Ironman.jpg';
import img5 from './assets/Batman.jpg';
import img6 from './assets/Twilight.jpg';
import img7 from './assets/Spiderman.jpg';
import img8 from './assets/Titanic.jpg';
import img9 from './assets/Founder.jpg';


export const vid = [{
    img: img6,
    title: 'Twilight ',
    description: 'IMDb : 8.9',
    price: '₹ 250',
    id: 1,
    addedToCart: false
}, {
    img: img2,
    title: 'The Alchemist',
    description: 'IMDb : 9',
    price: '₹ 150',
    id: 2
}, {
    img: img3,
    title: 'The Invisible man',
    description: 'IMDb : 8.3',
    price: '₹ 200',
    id: 3
}, {
    img: img4,
    title: 'Ironman',
    description: 'IMDb : 8.5',
    price: '₹ 270',
    id: 4
}, {
    img: img5,
    title: 'Batman',
    description: 'IMDb : 9.1',
    price: '₹ 160',
    id: 5
},{
    img: img1,
    title: 'Ms Dhoni',
    description: 'IMDb : 8.8',
    price: '₹ 270',
    id: 6
}, {
    img: img7,
    title: 'Spiderman 3',
    description: 'IMDb : 8.1',
    price: '₹ 180',
    id: 7
}, {
    img: img8,
    title: 'Titanic',
    description: 'IMDb : 8.7',
    price: '₹ 220',
    id: 8
}, 

{
    img: img9,
    title: 'The Founder',
    description: 'IMDb : 8.2',
    price: '₹ 210',
    id: 9
}
]