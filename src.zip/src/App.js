import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Card, Navbar } from 'react-bootstrap';
import NavbarComp from './components/NavbarComp';
import Content from './components/Content';
import Footer from './components/Footer';
import { useState } from "react";
import { Routes, Route, Link } from "react-router-dom";
import Home from './Home';
import About from './About';
import Cart from './Cart';
import { vid } from './mocks';

function App() {

  const [selectedItems, setSelectedItem] = useState([]);


  return (
    <>
      <div className="App">
        <NavbarComp />
        { /* <Navbar /> */}
      </div>
      <div>
        <Routes>
          <Route exact path="/" element={<Home vid={vid} setSelectedItem={setSelectedItem} selectedItems={selectedItems} />}></Route>
          <Route path="/about" element={<About />}></Route>
          <Route path="/cart" element={<Cart selectedItems={selectedItems} setSelectedItem={setSelectedItem}/>}></Route>
        </Routes>
      </div>
    </>

  );
}

export default App;
