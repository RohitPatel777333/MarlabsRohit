import React, { Component } from "react";

const Cart = (props) => {
  //   let Totalprice = 0;
  //   //   cartdata.map((b) => (Totalprice = b.price + Totalprice));
  const { setSelectedItem, selectedItems } = props;

  return (
    <div>
      <table className="cart">
        <thead>
          <tr>
            <th>Sl No</th>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {
            selectedItems.map((val, i) => {
              return (<tr key={val.id}>
                <td> {i + 1} </td>
                <td> {val.id} </td>
                <td> {val.title} </td>
                <td> {val.price} </td>
              </tr>)
            })
          }
        </tbody>
      </table>
      <div className="cart-container">
      <button className="empty-cart" onClick={() => setSelectedItem([])}>
        Empty Cart
      </button>
      </div>
      {/* <div className="row">
        {cartdata.map((c) => (
          <div className="col-sm-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">{c.BookName}</h5>
                <p className="card-text">{c.Author}</p>
                <p className="card-text"> {c.price}</p>
                <a href="#" className="btn btn-primary"></a>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="col-sm-6 placeorder">
    <div className="card">
             <div className="card-body">
                <h5 className="card-title">Total</h5>
                <p className="card-text"></p>
                <p className="card-text"> </p>
                <a href="#" className="btn btn-primary">
                    Place order
                </a>
            </div>
        </div>
    </div> */}
      {/* <h1> Your Cart is Empty</h1> */}
    </div>
  );
};
export default Cart;




// function Cart() {
//     return (
//         <h1> Your Cart is empty</h1>
//     )
// }

// export default Cart
