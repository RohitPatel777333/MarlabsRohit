function About() {
    return (
        <h1> About Netflix</h1>
    )
}

export default About
